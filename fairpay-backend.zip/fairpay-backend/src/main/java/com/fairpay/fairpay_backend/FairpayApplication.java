package com.fairpay.fairpay_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FairpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FairpayApplication.class, args);
	}

}
